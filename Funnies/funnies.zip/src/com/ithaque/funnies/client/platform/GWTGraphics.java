package com.ithaque.funnies.client.platform;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gwt.canvas.client.Canvas;
import com.google.gwt.canvas.dom.client.Context2d;
import com.google.gwt.dom.client.ImageElement;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.LoadEvent;
import com.google.gwt.event.dom.client.LoadHandler;
import com.google.gwt.event.dom.client.MouseDownEvent;
import com.google.gwt.event.dom.client.MouseDownHandler;
import com.google.gwt.event.dom.client.MouseMoveEvent;
import com.google.gwt.event.dom.client.MouseMoveHandler;
import com.google.gwt.event.dom.client.MouseUpEvent;
import com.google.gwt.event.dom.client.MouseUpHandler;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.RootPanel;
import com.ithaque.funnies.shared.basic.Board;
import com.ithaque.funnies.shared.basic.Event;
import com.ithaque.funnies.shared.basic.Event.Type;
import com.ithaque.funnies.shared.basic.Graphics;
import com.ithaque.funnies.shared.basic.Item;
import com.ithaque.funnies.shared.basic.ItemHolder;
import com.ithaque.funnies.shared.basic.Location;
import com.ithaque.funnies.shared.basic.Moveable;
import com.ithaque.funnies.shared.basic.item.ImageItem;

public class GWTGraphics implements Graphics {

	GWTPlatform platform;
	int tokenCount = 0;
	Context2d context2d;
	Canvas flipCanvas;
	Canvas flopCanvas;
	Canvas canvas;
	Map<String, Integer> imageTokens = new HashMap<String, Integer>();
	Map<Integer, ImageElementRecord> imageElements = new HashMap<Integer, ImageElementRecord>();
	boolean drag = false;
	boolean debug = true;
	
	public GWTGraphics(GWTPlatform platform) {
		this.platform = platform;
	}
	
	ClickHandler clickHandler = new ClickHandler() {
		@Override
		public void onClick(ClickEvent event) {
			processClick(event);
		}
	};

	MouseDownHandler mouseDownHandler = new MouseDownHandler() {
		@Override
		public void onMouseDown(MouseDownEvent event) {
			processMouseDown(event);
		}
	};
	
	MouseUpHandler mouseUpHandler = new MouseUpHandler() {
		@Override
		public void onMouseUp(MouseUpEvent event) {
			processMouseUp(event);
		}
	};

	MouseMoveHandler mouseMoveHandler = new MouseMoveHandler() {
		@Override
		public void onMouseMove(MouseMoveEvent event) {
			processMouseMove(event);
		}
	};
	
	static class ImageElementRecord {
		int count = 1;
		String url;
		boolean ready = false;
		ImageElement image = null;
		List<DrawImageRequest> requests = null;
		
		public ImageElementRecord(String url) {
			this.url = url;
		}
		
		public void addRequest(DrawImageRequest request) {
			if (requests == null) {
				requests = new ArrayList<DrawImageRequest>();
			}
			requests.add(request);
		}
	}
	
	class DrawImageRequest {
		
		ImageItem imageItem;
		
		public DrawImageRequest(ImageItem imageItem) {
			this.imageItem = imageItem;
		}
		
		public ImageItem getImageItem() {
			return imageItem;
		}
		
		public void draw(Context2d context2d, ImageElement image) {
			Transform transform = transform(imageItem);
			if (transform!=null) {
				context2d.setTransform(transform.m[0], transform.m[1], transform.m[2], transform.m[3], transform.m[4], transform.m[5]);
				context2d.translate(-image.getWidth()/2.0f, -image.getHeight()/2.0f);
				context2d.drawImage(image, 0, 0, image.getWidth(), image.getHeight());
			}
		}
	}
	
	public Transform transform(Moveable item) {
		Transform transform = new Transform();
		transform.translate(getCenterX(), getCenterY());
		if (!transform(item, transform)) {
			return null;
		}
		return transform;
	}
	
	boolean transform(Moveable moveable, Transform transform) {
		if (moveable==null) {
			return false;
		}
		else {
			if (!(moveable instanceof Board)) {
				if (!transform(((Item)moveable).getParent(), transform)) {
					return false;
				}
			}
			Location translation = moveable.getLocation();
			if (translation!=null && !translation.equals(Location.ORIGIN)) {
				transform.translate(translation.getX(), translation.getY());
			}
			if (moveable.getScale()!=ItemHolder.STANDARD_SCALE) {
				transform.scale(moveable.getScale(), moveable.getScale());
			}
			if (moveable.getRotation()!=ItemHolder.NO_ROTATION) {
				transform.rotate(moveable.getRotation());
			}
			return true;
		}
	}
	
	protected float getCenterX() {
		return canvas.getCoordinateSpaceWidth()/2.0f;
	}
	
	protected float getCenterY() {
		return canvas.getCoordinateSpaceHeight()/2.0f;
	}
	
	public void start() {
	    canvas = flipCanvas = createCanvas(true);
	    flopCanvas = createCanvas(false);
	}

	Canvas createCanvas(boolean visible) {
	    Canvas canvas = Canvas.createIfSupported();
	    canvas.setVisible(visible);
	    canvas.setCoordinateSpaceWidth(1000);
	    canvas.setCoordinateSpaceHeight(500);
	    canvas.addClickHandler(clickHandler);
	    canvas.addMouseDownHandler(mouseDownHandler);
	    canvas.addMouseUpHandler(mouseUpHandler);
	    canvas.addMouseMoveHandler(mouseMoveHandler);
	    RootPanel.get("board").add(canvas);
		return canvas;
	}
	
	@Override
	public void drawImage(ImageItem imageItem) {
		drawRequest(new DrawImageRequest(imageItem));
	}
	
	void drawRequest(DrawImageRequest request) {
		ImageElementRecord record = imageElements.get(request.getImageItem().getToken());
		if (record.ready) {
			request.draw(context2d, record.image);
		}
		else {
			record.addRequest(request);
		}
	}
	
	@Override
	public Integer loadImage(String url) {
		Integer token = imageTokens.get(url);
		if (token!=null) {
			ImageElementRecord record = imageElements.get(token);
			record.count++;
			return token;
		}
		token = tokenCount++;
		final ImageElementRecord record = new ImageElementRecord(url);
		imageElements.put(token, record);
	    final Image img = new Image(url);
	    record.image = ImageElement.as(img.getElement());
	    img.addLoadHandler(new LoadHandler() {
	        @Override
	        public void onLoad(LoadEvent event) {
	        	RootPanel.get("images").remove(img);
	        	record.ready = true;
	        	for (DrawImageRequest request : record.requests) {
	        		drawRequest(request);
	        	}
	            record.requests = null;
	        }
	    });
	    img.setVisible(false);
	    RootPanel.get("images").add(img);
	    return token;
	}

	@Override
	public void clear() {
		if (flipCanvas==canvas) {
			canvas = flopCanvas;
			flipCanvas.setVisible(false);
			flopCanvas.setVisible(true);
		}
		else {
			canvas = flipCanvas;
			flipCanvas.setVisible(true);
			flopCanvas.setVisible(false);
		}
	    context2d = canvas.getContext2d();
		context2d.setTransform(1, 0, 0, 1, 0, 0);
		context2d.clearRect(0, 0, canvas.getCoordinateSpaceWidth(), canvas.getCoordinateSpaceHeight());
	}

	void processClick(ClickEvent event) {
		platform.sendEvent(new Event(Type.MOUSE_CLICK, event.getX(), event.getY(), 
			event.getNativeButton()==NativeEvent.BUTTON_RIGHT, 
			event.isShiftKeyDown(), event.isControlKeyDown(), event.isAltKeyDown()));
	}

	void processMouseDown(MouseDownEvent event) {
		drag = true;
		platform.sendEvent(new Event(Type.MOUSE_DOWN, event.getX(), event.getY(), 
			event.getNativeButton()==NativeEvent.BUTTON_RIGHT, 
			event.isShiftKeyDown(), event.isControlKeyDown(), event.isAltKeyDown()));
	}
	
	void processMouseUp(MouseUpEvent event) {
		drag = false;
		platform.sendEvent(new Event(Type.MOUSE_UP, event.getX(), event.getY(), 
			event.getNativeButton()==NativeEvent.BUTTON_RIGHT, 
			event.isShiftKeyDown(), event.isControlKeyDown(), event.isAltKeyDown()));
	}
	
	void processMouseMove(MouseMoveEvent event) {
		platform.sendEvent(new Event(drag?Type.MOUSE_DRAG:Type.MOUSE_MOVE, event.getX(), event.getY(), 
			event.getNativeButton()==NativeEvent.BUTTON_RIGHT, 
			event.isShiftKeyDown(), event.isControlKeyDown(), event.isAltKeyDown()));
	}
	
	public boolean isTarget(Item item, Location point, Location[] shape) {
		Transform transform = transform(item).invert();
		if (debug) {
			drawShape(item, shape);
		}
		return Geometric.inside(transform.transformPoint(point), shape);
	}

	public void drawShape(Item item, Location[] shape) {
		Location[] trShape = transformShape(item, shape);
		context2d.beginPath();
		context2d.setTransform(1, 0, 0, 1, 0, 0);
		context2d.moveTo(trShape[0].getX(), trShape[0].getY());
		for (int i=1; i<trShape.length; i++) {
			context2d.lineTo(trShape[i].getX(), trShape[i].getY());
		}		
		context2d.lineTo(trShape[0].getX(), trShape[0].getY());
		context2d.stroke();
	}

	Location[] transformShape(Item item, Location[] shape) {
		Transform transform = transform(item);
		Location[] trShape = new Location[shape.length];
		for (int i=0; i<shape.length; i++) {
			trShape[i] = transform.transformPoint(shape[i]);
		}
		return trShape;
	}
	
	@Override
	public Location[] getShape(ImageItem imageItem) {
		ImageElementRecord imageRecord = imageElements.get(imageItem.getToken());
		if (imageRecord.ready) {
			float width = imageRecord.image.getWidth();
			float height = imageRecord.image.getHeight();
			Location upperLeft = new Location(-width/2.0f, -height/2.0f);
			Location upperRight = new Location(width/2.0f, -height/2.0f);
			Location bottomRight = new Location(width/2.0f, height/2.0f);
			Location bottomLeft = new Location(-width/2.0f, height/2.0f);
			return new Location[] {upperLeft, upperRight, bottomRight, bottomLeft};
		}
		else {
			return null;
		}
	}

	@Override
	public Location invertTransformLocation(Moveable item, Location location) {
		Transform transform = transform(item).invert();
		return transform==null ? null : transform.transformPoint(location);
	}

	@Override
	public Location transformLocation(Moveable item, Location location) {
		Transform transform = transform(item);
		return transform==null ? null : transform.transformPoint(location);
	}
}
