package com.ithaque.funnies.client.platform;

import com.ithaque.funnies.shared.basic.Location;

public class Geometric {

	public static int ccw(Location p0, Location p1, Location p2) {
		float dx1, dx2, dy1, dy2;
		dx1 = p1.getX() - p0.getX();
		dy1 = p1.getY() - p0.getY();
		dx2 = p2.getX() - p0.getX();
		dy2 = p2.getY() - p0.getY();
		if (dx1 * dy2 > dy1 * dx2)
			return +1;
		if (dx1 * dy2 < dy1 * dx2)
			return -1;
		if ((dx1 * dx2 < 0) || (dy1 * dy2 < 0))
			return -1;
		if ((dx1 * dx1 + dy1 * dy1) < (dx2 * dx2 + dy2 * dy2))
			return +1;
		return 0;
	}

	public static boolean intersect(Location l1p1, Location l1p2, Location l2p1, Location l2p2) {
		return ((ccw(l1p1, l1p2, l2p1) * ccw(l1p1, l1p2, l2p2)) <= 0)
			&& ((ccw(l2p1, l2p2, l1p1) * ccw(l2p1, l2p2, l1p2)) <= 0);
	}

	public static boolean inside(Location t, Location ... p) {
		int i, count = 0, j = 0;
		
		float minY = p[0].getY();
		for (i=1; i<p.length; i++) {
			if (minY<p[i].getY()) {
				minY=p[i].getY();
			}
		}
		int start = 0;
		float minX = Integer.MIN_VALUE;
		for (i=0; i<p.length; i++) {
			if (p[i].getY()==minY && p[i].getX()<minX) {
				minX = p[i].getX();
				start = i;
			}
		}
		
		int N = p.length;
		Location[] poly = new Location[N+2];
		for (i=0; i<p.length; i++) {
			poly[i+1] = p[(start+i)%p.length];
		}
		poly[0] = poly[N]; 
		poly[N+1] = poly[1];
		
		Location farAway = new Location(Integer.MAX_VALUE, t.getY());
		for (i = 1; i <= N; i++) {
			if (!intersect(poly[i], poly[i], t, farAway)) {
				if (intersect(poly[i], poly[j], t, farAway)) 
					count++;
				j = i;
			}
		}
		return (count & 1)!=0;
	}
	
}
