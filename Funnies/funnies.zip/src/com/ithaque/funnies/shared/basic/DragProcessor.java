package com.ithaque.funnies.shared.basic;

import java.util.ArrayList;
import java.util.List;

import com.ithaque.funnies.shared.basic.Event.Type;
import com.ithaque.funnies.shared.basic.item.ImageItemAnimation;
import com.ithaque.funnies.shared.basic.item.OutBackEasing;

public class DragProcessor extends Processor {

	List<DragProfile> dragProfiles = new ArrayList<DragProfile>();
	DragProfile inDrag = null;
	
	@Override
	public boolean process(Event event, Board board) {
		if (event.getType()==Type.MOUSE_DOWN) {
			if (inDrag==null) {
				inDrag = processBeginDrag(event, board);
			}
			return inDrag!=null;
		}
		else if(inDrag!=null && event.getType()==Type.MOUSE_UP) {
			processDrop(event, board);
			inDrag=null;
			return true;
		}
		else if (inDrag!=null && event.getType()==Type.MOUSE_DRAG) {
			processDrag(event, board);
			return true;
		}
		return super.process(event, board);
	}

	protected void processDrag(Event event, Board board) {
		inDrag.drag(event, board);
	}

	protected void processDrop(Event event, Board board) {
		inDrag.drop(event, board);
	}

	protected DragProfile processBeginDrag(Event event, Board board) {
		for (DragProfile profile : new ArrayList<DragProfile>(dragProfiles)) {
			if (profile.beginDrag(event, board)) {
				return profile;
			}
		}
		return null;
	}

	public interface DragProfile {
		boolean beginDrag(Event event, Board board);
		void drag(Event event, Board board);
		void drop(Event event, Board board);
	}
	
	public void addDragProfile(DragProfile dragProfile) {
		dragProfiles.add(dragProfile);
	}

	public void removeDragProfile(DragProfile dragProfile) {
		dragProfiles.remove(dragProfile);
	}
	
	public static Location getAnchor(Event event, Item dragged) {
		Location mouseLocation = new Location(event.getX(), event.getY());
		Location newLocation = dragged.getBoard().getGraphics().invertTransformLocation((Item)dragged.getParent(), mouseLocation);
		Location startLocation = dragged.getLocation();
		return new Location(newLocation.getX()-startLocation.getX(), newLocation.getY()-startLocation.getY());
	}

	public static Location followMouse(Event event, Item dragged, Location anchor) {
		Location mouseLocation = new Location(event.getX(), event.getY());
		Location newLocation = dragged.getBoard().getGraphics().invertTransformLocation((Item)dragged.getParent(), mouseLocation);
		return new Location(
			newLocation.getX()-anchor.getX(), 
			newLocation.getY()-anchor.getY());
	}
	
	public static void movetoTarget(Item dragged, Item target) {
		Location targetLocation = target.getLocation();
		Location absLocation = target.getBoard().getGraphics().transformLocation(target.getParent(), targetLocation);
		Location draggedLocation = dragged.getBoard().getGraphics().invertTransformLocation(dragged.getParent(), absLocation);
		new ImageItemAnimation(new OutBackEasing(1000), draggedLocation, null, null).launchFor(dragged);
	}
	
	public static class BasicDragProfile implements DragProfile {

		Item dragged;
		Location anchor;
		Location startLocation;
		
		@Override
		public boolean beginDrag(Event event, Board board) {
			Item dragged = board.getTarget(event);
			if (dragged!=null && acceptDraggeable(dragged)) {
				this.dragged = dragged;
				startLocation = dragged.getLocation();
				anchor = getAnchor(event, dragged);
			}
			return this.dragged!=null;
		}

		protected boolean acceptDraggeable(Item draggeable) {
			return true;
		}

		@Override
		public void drag(Event event, Board board) {
			dragged.setLocation(DragProcessor.followMouse(event, dragged, anchor));
		}

		@Override
		public void drop(Event event, Board board) {
			if (executeDrop(event, board)) {
				dragged.setLocation(DragProcessor.followMouse(event, dragged, anchor));
			}
			else {
				new ImageItemAnimation(new OutBackEasing(1000), startLocation, null, null).launchFor(dragged);
			}
			dragged = null;
		}

		protected boolean executeDrop(Event event, Board board) {
			return false;
		}
		
	}
	
	public static class TargetedDragProfile extends BasicDragProfile {

		List<Item> draggeables = new ArrayList<Item>();
		List<Item> targets = new ArrayList<Item>();

		protected boolean acceptDraggeable(Item draggeable) {
			return draggeables.contains(draggeable);
		}
		
		public void addDraggeable(Item draggeable) {
			draggeables.add(draggeable);
		}
		
		public void removeDraggeable(Item draggeable) {
			draggeables.remove(draggeable);
		}
		
		public void addTarget(Item target) {
			targets.add(target);
		}
		
		public void removeTarget(Item target) {
			targets.remove(target);
		}

		protected boolean executeDrop(Event event, Board board) {
			Item target = getTarget(event);
			return target==null ? false : dropOnTarget(dragged, target);
		}
		
		protected boolean dropOnTarget(Item dragged, Item target) {
			if (executeDrop(dragged, target)) {
				movetoTarget(dragged, target);
				return true;
			}
			else {
				return false;
			}
		}

		protected boolean executeDrop(Item dragged, Item target) {
			return true;
		}

		protected Item getTarget(Event event) {
			for (Item target : new ArrayList<Item>(targets)) {
				if (target.acceptEvent(event) && acceptTarget(target)) {
					return target;
				}
			}
			return null;
		}

		protected boolean acceptTarget(Item target) {
			return true;
		}

	}
	
}
