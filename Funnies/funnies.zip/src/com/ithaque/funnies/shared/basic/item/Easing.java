package com.ithaque.funnies.shared.basic.item;

import com.ithaque.funnies.shared.basic.Board;

public interface Easing {

	void launch(Board board);

	long getEndTime();

	float getValue(float base, float target);

}
