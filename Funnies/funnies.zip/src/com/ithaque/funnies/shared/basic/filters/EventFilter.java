package com.ithaque.funnies.shared.basic.filters;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.ithaque.funnies.shared.basic.Event;
import com.ithaque.funnies.shared.basic.Item;
import com.ithaque.funnies.shared.basic.ItemFilter;

public class EventFilter extends ItemFilter {

	Event event = null;
	
	public EventFilter(ItemFilter filter, Event event) {
		super(filter);
		this.event = event;
	}

	public EventFilter(Event event) {
		super();
		this.event = event;
	}

	@Override
	public Collection<Item> filter(Collection<Item> items) {
		List<Item> filteredItems = new ArrayList<Item>();
		for (Item item : items) {
			System.out.println("Filer..."+item);
			if (item.acceptEvent(event)) {
				filteredItems.add(item);
			}
		}
		return filteredItems;
	}

}
