package com.ithaque.funnies.shared.basic;

public class Processor {

	public boolean process(Event event, Board board) {
		return false;
	}

}
