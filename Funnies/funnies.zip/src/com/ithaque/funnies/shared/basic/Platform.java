package com.ithaque.funnies.shared.basic;

public interface Platform {

	Graphics getGraphics();

	long getTime();

	void start(Board board);
}
