package com.ithaque.funnies.shared.basic;


public class Layer extends GroupItem {

	public void addItem(Item item, float x, float y) {
		item.setLocation(new Location(x, y));
		addItem(item);
	}	

}
