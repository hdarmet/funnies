package com.ithaque.funnies.shared.basic;

import com.ithaque.funnies.shared.basic.item.ImageItem;

public interface Graphics {
	
	Integer loadImage(String url);

	void drawImage(ImageItem imageItem);

	boolean isTarget(Item item, Location point, Location[] shape);
	
	void clear();

	Location[] getShape(ImageItem imageItem);

	Location invertTransformLocation(Moveable dragged, Location location);

	Location transformLocation(Moveable dragged, Location location);
	
}
