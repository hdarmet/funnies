package com.ithaque.funnies.shared.basic;

import java.util.HashSet;
import java.util.Set;

public class Item implements Moveable {

	ItemHolder parent = null;
	Location location = Location.ORIGIN;
	float scale = ItemHolder.STANDARD_SCALE;
	float rotation = ItemHolder.NO_ROTATION;
	Set<Event.Type> eventTypes = new HashSet<Event.Type>();
	
	public void setParent(ItemHolder parent) {
		Board oldBoard = getBoard();
		this.parent = parent;
		Board newBoard = getBoard();
		registerOnBoard(oldBoard, newBoard);
		dirty();
	}

	protected void registerOnBoard(Board oldBoard, Board newBoard) {
		if (oldBoard == newBoard) {
			return;
		}
		if (oldBoard != null) {
			oldBoard.unregister(this);
		}
		if (newBoard != null) {
			newBoard.register(this);
		}
	}

	public Set<Event.Type> getEventTypes() {
		return eventTypes;
	}
	
	public void addEventType(Event.Type eventType) {
		if (!eventTypes.contains(eventType)) {
			eventTypes.add(eventType);
			Board board = getBoard();
			if (board!=null) {
				board.registerEvent(this, eventType);
			}
		}
	}

	public void removeEventType(Event.Type eventType) {
		if (eventTypes.contains(eventType)) {
			eventTypes.remove(eventType);
			Board board = getBoard();
			if (board!=null) {
				board.unregisterEvent(this, eventType);
			}
		}
	}

	public Location getLocation() {
		return location;
	}
	
	public void setLocation(float x, float y) {
		setLocation(new Location(x, y));
		dirty();
	}
	
	public void setLocation(Location location) {
		this.location = location;
		dirty();
	}
	
	public float getScale() {
		return scale;
	}

	public void setScale(float scale) {
		this.scale = scale;
		dirty();
	}

	public float getRotation() {
		return rotation;
	}

	public void setAngle(float angle) {
		this.rotation = angle;
		dirty();
	}
	
	public void free() {
		dirty();
		if (parent!=null) {
			parent.removeItem(this);
		}
	}

	public ItemHolder getParent() {
		return parent;
	}

	public void render(Graphics graphics) {
	}
	
	public Board getBoard() {
		return parent==null ? null : parent.getBoard();
	}

	public void dirty() {
		if (parent!=null) {
			parent.dirty();
		}
	}
	
	public boolean acceptEvent(Event event) {
		Location[] shape = getShape();
		if (shape==null) {
			return false;
		}
		else {
			return getBoard().getGraphics().isTarget(this, new Location(event.getX(), event.getY()), shape);
		}
	}
	
	public Location[] getShape() {
		return null;
	}
}
