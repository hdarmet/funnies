package com.ithaque.funnies.shared.basic.item;

import com.ithaque.funnies.shared.basic.Graphics;
import com.ithaque.funnies.shared.basic.Item;
import com.ithaque.funnies.shared.basic.Location;

public class ImageItem extends Item {

	Integer token = null;
	String url = null;
	
	public ImageItem(String url) {
		setUrl(url);
	}
	
	public void setUrl(String url) {
		if (!url.equals(this.url)) {
			this.url = url;
			this.token = null;
			dirty();
		}
	}

	public String getUrl() {
		return url;
	}

	public Integer getToken() {
		if (token==null) {
			token = getBoard().getGraphics().loadImage(url);
		}
		return token;
	}
	
	@Override
	public void render(Graphics graphics) {
		graphics.drawImage(this);
		super.render(graphics);
	}
	
	@Override
	public Location[] getShape() {
		return getBoard().getGraphics().getShape(this);
	}
}
