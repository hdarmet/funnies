package com.ithaque.funnies.shared.basic.item;

import com.ithaque.funnies.shared.basic.Animation;
import com.ithaque.funnies.shared.basic.Item;
import com.ithaque.funnies.shared.basic.Location;

public class ImageItemAnimation implements Animation {

	Item item;
	Easing easing;
	Location newLocation;
	Float newAngle;
	Float newScale;
	
	Location baseLocation;
	float baseAngle;
	float baseScale;
	
	public ImageItemAnimation(Easing timeKeeper, Location newLocation, Float newAngle, Float newScale) {
		this.easing = timeKeeper;
		this.newLocation = newLocation;
		this.newAngle = newAngle;
		this.newScale = newScale;
	}

	public ImageItemAnimation(long duration, float x, float y, Float newAngle, Float newScale) {
		this(new SineInOutEasing(duration), new Location(x, y), newAngle, newScale);
	}
	
	public void launchFor(Item item) {
		this.item = item;
		this.baseLocation = item.getLocation();
		this.baseAngle = item.getRotation();
		this.baseScale = item.getScale();
		this.easing.launch(item.getBoard());
		item.getBoard().launchAnimation(this);
	}
	
	@Override
	public boolean animate(long time) {
		if (time+Animation.INTERVAL>=easing.getEndTime()) {
			return false;
		}
		else {
			if (this.newLocation != null) {
				Location location = item.getLocation();
				if (location!=null && newLocation!=null) {
					item.setLocation(
						easing.getValue(baseLocation.getX(), newLocation.getX()),
						easing.getValue(baseLocation.getY(), newLocation.getY()));
				}
			}
			if (newAngle!=null) {
				item.setAngle(easing.getValue(baseAngle, newAngle));
			}
			if (newScale!=null) {
				item.setScale(easing.getValue(baseScale, newScale));
			}
			return true;
		}
	}

	@Override
	public void finish(long time) {
		if (this.newLocation!=null) {
			item.setLocation(newLocation);
		}
		if (this.newAngle!=null) {
			item.setAngle(newAngle);
		}
		if (this.newScale!=null) {
			item.setScale(newScale);
		}
	}

	@Override
	public boolean start(long time) {
		return true;
	}

}
