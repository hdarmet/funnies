package com.ithaque.funnies.shared.basic;

public class Event {

	public enum Type {
		MOUSE_DOWN,
		MOUSE_UP,
		MOUSE_CLICK,
		MOUSE_MOVE,
		MOUSE_DRAG,
		KEY_PRESSED,
		KEY_RELEASED,
		KEY_ENTER,
		ALARM
	}
	
	Type type;
	int x, y;
	boolean right;
	
	int key;
	
	String alarm;
	long time;
	
	boolean shift;
	boolean ctrl;
	boolean alt;
	
	public Event(Type type, int x, int y, boolean right, boolean shift, boolean ctrl, boolean alt) {
		this.type = type;
		this.x = x;
		this.y = y;
		this.right = right;
		this.shift = shift;
		this.ctrl = ctrl;
		this.alt = alt;
	}
	
	public Event(Type type, char key, boolean shift, boolean ctrl, boolean alt) {
		this.type = type;
		this.key = key;
		this.shift = shift;
		this.ctrl = ctrl;
		this.alt = alt;
	}

	public Event(Type type, String alarm, long time) {
		this.type = type;
		this.time = time;
		this.alarm = alarm;
	}
	
	public Type getType() {
		return type;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public boolean isRight() {
		return right;
	}

	public int getKey() {
		return key;
	}

	public boolean isShift() {
		return shift;
	}

	public boolean isCtrl() {
		return ctrl;
	}

	public boolean isAlt() {
		return alt;
	}
	
	public long getTime() {
		return time;
	}
	
	public String getAlarm() {
		return alarm;
	}
}
