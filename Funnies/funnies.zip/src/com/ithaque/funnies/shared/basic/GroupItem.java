package com.ithaque.funnies.shared.basic;

import java.util.ArrayList;
import java.util.List;

public class GroupItem extends Item implements ItemHolder {

	List<Item> items = new ArrayList<Item>();
	
	public void render(Graphics graphics) {
		for (Item item : items) {
			renderItem(graphics, item);
		}
		super.render(graphics);
	}

	protected void renderItem(Graphics graphics, Item item) {
		item.render(graphics);
	}
	
	@Override
	public void addItem(Item item) {
		if (items.isEmpty() || items.get(items.size()-1)!=item) {
			item.free();
			item.setParent(this);
			items.add(item);
		}
	}
	
	@Override
	public void setItem(int index, Item item) {
		if (items.isEmpty() || items.get(index)!=item) {
			item.free();
			item.setParent(this);
			items.set(index, item);
		}
	}

	@Override
	public void removeItem(Item item) {
		if (item.getParent()==this) {
			items.remove(item);
			item.setParent(this);
		}
	}

	@Override
	public boolean contains(Item item) {
		return items.contains(item);
	}
	
	@Override
	protected void registerOnBoard(Board oldBoard, Board newBoard) {
		super.registerOnBoard(oldBoard, newBoard);
		for (Item item : items) {
			item.registerOnBoard(oldBoard, newBoard);
		}
	}
	
	@Override
	public int indexOfItem(Item item) {
		return items.indexOf(item);
	}
	
}
